package i18n

import "github.com/nicksnyder/go-i18n/v2/internal"

// Message is a string that can be localized.
type Message = internal.Message
