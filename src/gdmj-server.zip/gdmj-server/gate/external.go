package gate

import (
	"gdmj-server/gate/internal"
)

var (
	Module = new(internal.Module)
)
